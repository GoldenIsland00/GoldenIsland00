from django.contrib.auth import views as auth_views
from django.urls import path

from . import views

urlpatterns = [
    # ورود و خروج
    path(
        "login/",
        auth_views.LoginView.as_view(
            template_name="accounting/login.html",
            redirect_authenticated_user=True,
        ),
        name="login",
    ),
    path("logout/", auth_views.LogoutView.as_view(), name="logout"),

    # رابط کاربری
    path("", views.app_view, name="app"),

    # API
    path("api/<str:store>/", views.collection_view, name="api-collection"),
    path("api/<str:store>/<str:pk>/", views.item_view, name="api-item"),
]
