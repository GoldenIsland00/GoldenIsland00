import json

from django.contrib.auth.decorators import login_required
from django.db.models import ProtectedError
from django.http import Http404, JsonResponse
from django.shortcuts import render
from django.views.decorators.csrf import ensure_csrf_cookie
from django.views.decorators.http import require_http_methods

from .defaults import DEFAULT_SETTINGS
from .models import Setting
from .serializers import REGISTRY, setting_to_dict


# =========================================================
#  صفحات
# =========================================================
@ensure_csrf_cookie
@login_required
def app_view(request):
    """صفحه اصلی نرم‌افزار (همان رابط تک‌صفحه‌ای)"""
    return render(request, "accounting/app.html")


# =========================================================
#  ابزارهای API
# =========================================================
def _body(request):
    try:
        return json.loads(request.body.decode("utf-8") or "{}")
    except (ValueError, UnicodeDecodeError):
        return {}


def _err(message, status=400):
    return JsonResponse({"detail": message}, status=status)


def _resolve(store):
    if store not in REGISTRY:
        raise Http404("منبع نامعتبر است")
    return REGISTRY[store]


# =========================================================
#  API — لیست و ایجاد:  /api/<store>/
# =========================================================
@login_required
@require_http_methods(["GET", "POST"])
def collection_view(request, store):
    if store == "settings":
        return _settings_collection(request)

    model, to_dict, from_dict = _resolve(store)

    if request.method == "GET":
        qs = model.objects.all()
        if store == "contracts":
            qs = qs.select_related("customer")
        if store == "transactions":
            qs = qs.select_related("contract")
        return JsonResponse([to_dict(o) for o in qs], safe=False)

    data = _body(request)
    obj = model()
    # هنگام بازیابی فایل پشتیبان، شناسه ارسال‌شده حفظ می‌شود
    if data.get("id"):
        obj.pk = int(data["id"])
    from_dict(obj, data)
    try:
        obj.save()
    except Exception as exc:  # مثلاً مشتری یا قرارداد نامعتبر
        return _err(f"ذخیره ناموفق بود: {exc}")
    return JsonResponse(to_dict(obj), status=201)


# =========================================================
#  API — خواندن/ویرایش/حذف یک رکورد:  /api/<store>/<pk>/
# =========================================================
@login_required
@require_http_methods(["GET", "PUT", "PATCH", "DELETE"])
def item_view(request, store, pk):
    if store == "settings":
        return _settings_item(request, pk)

    model, to_dict, from_dict = _resolve(store)

    try:
        obj = model.objects.get(pk=int(pk))
    except (model.DoesNotExist, ValueError):
        return _err("رکورد پیدا نشد", 404)

    if request.method == "GET":
        return JsonResponse(to_dict(obj))

    if request.method == "DELETE":
        try:
            obj.delete()
        except ProtectedError:
            return _err("این رکورد به رکوردهای دیگر وابسته است و حذف نمی‌شود", 409)
        return JsonResponse({"deleted": True})

    from_dict(obj, _body(request))
    try:
        obj.save()
    except Exception as exc:
        return _err(f"ذخیره ناموفق بود: {exc}")
    return JsonResponse(to_dict(obj))


# =========================================================
#  API — تنظیمات (کلید/مقدار)
# =========================================================
def _settings_collection(request):
    if request.method == "GET":
        rows = list(Setting.objects.all())
        if not rows:  # اولین اجرا: مقادیر پیش‌فرض ساخته می‌شوند
            Setting.objects.bulk_create(
                [Setting(key=k, value=v) for k, v in DEFAULT_SETTINGS.items()]
            )
            rows = list(Setting.objects.all())
        return JsonResponse([setting_to_dict(o) for o in rows], safe=False)

    data = _body(request)
    key = str(data.get("key") or "").strip()
    if not key:
        return _err("کلید تنظیم الزامی است")
    obj, _ = Setting.objects.update_or_create(
        key=key, defaults={"value": str(data.get("value") or "")}
    )
    return JsonResponse(setting_to_dict(obj), status=201)


def _settings_item(request, pk):
    key = str(pk)
    if request.method == "DELETE":
        Setting.objects.filter(key=key).delete()
        return JsonResponse({"deleted": True})

    if request.method == "GET":
        try:
            return JsonResponse(setting_to_dict(Setting.objects.get(key=key)))
        except Setting.DoesNotExist:
            return _err("تنظیم پیدا نشد", 404)

    data = _body(request)
    obj, _ = Setting.objects.update_or_create(
        key=key, defaults={"value": str(data.get("value") or "")}
    )
    return JsonResponse(setting_to_dict(obj))
