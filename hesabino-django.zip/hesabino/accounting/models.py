from django.db import models


class TimeStamped(models.Model):
    created_at = models.DateTimeField("تاریخ ثبت", auto_now_add=True)
    updated_at = models.DateTimeField("آخرین ویرایش", auto_now=True)

    class Meta:
        abstract = True


class Customer(TimeStamped):
    name = models.CharField("نام / شرکت", max_length=200)
    phone = models.CharField("شماره تماس", max_length=40, blank=True)
    email = models.EmailField("ایمیل", blank=True)
    note_code = models.CharField("کد نظرات", max_length=60, blank=True)
    national_id = models.CharField("شناسه / کد ملی", max_length=40, blank=True)
    address = models.CharField("آدرس", max_length=400, blank=True)
    notes = models.TextField("یادداشت‌ها", blank=True)

    class Meta:
        verbose_name = "مشتری"
        verbose_name_plural = "مشتری‌ها"
        ordering = ("name",)

    def __str__(self):
        return self.name

    @property
    def contracts_total(self):
        return sum(c.total_amount for c in self.contracts.all())


class Project(TimeStamped):
    name = models.CharField("نام خدمت", max_length=200)
    description = models.TextField("توضیحات", blank=True)
    sample_url = models.CharField("آدرس نمونه‌کار", max_length=400, blank=True)
    start_price = models.BigIntegerField("شروع قیمت (تومان)", default=0)
    techs = models.JSONField("تکنولوژی‌ها", default=list, blank=True)

    class Meta:
        verbose_name = "پروژه / خدمت"
        verbose_name_plural = "پروژه‌ها و خدمات"
        ordering = ("name",)

    def __str__(self):
        return self.name


class Contract(TimeStamped):
    STATUS_CHOICES = [
        ("active", "در حال انجام"),
        ("completed", "تکمیل شده"),
        ("canceled", "لغو شده"),
    ]

    number = models.CharField("شماره قرارداد", max_length=60)
    customer = models.ForeignKey(
        Customer,
        verbose_name="مشتری",
        on_delete=models.PROTECT,
        related_name="contracts",
    )
    manager_name = models.CharField("انجام‌دهنده (مجری)", max_length=200, blank=True)
    manager_info = models.CharField("مشخصات مجری", max_length=400, blank=True)
    start_date = models.DateField("تاریخ شروع", null=True, blank=True)
    end_date = models.DateField("تاریخ اتمام", null=True, blank=True)
    total_amount = models.BigIntegerField("مبلغ کل (تومان)", default=0)
    prepayment = models.BigIntegerField("پیش‌پرداخت (تومان)", default=0)
    status = models.CharField(
        "وضعیت", max_length=20, choices=STATUS_CHOICES, default="active"
    )
    text = models.TextField("متن قرارداد", blank=True)
    items = models.JSONField("ردیف‌های خدمات", default=list, blank=True)

    class Meta:
        verbose_name = "قرارداد"
        verbose_name_plural = "قراردادها"
        ordering = ("-id",)

    def __str__(self):
        return f"{self.number} — {self.customer.name}"

    @property
    def paid(self):
        return sum(t.amount for t in self.transactions.all())

    @property
    def remaining(self):
        return self.total_amount - self.paid


class Transaction(models.Model):
    contract = models.ForeignKey(
        Contract,
        verbose_name="قرارداد",
        on_delete=models.CASCADE,
        related_name="transactions",
    )
    amount = models.BigIntegerField("مبلغ (تومان)", default=0)
    from_card = models.CharField("از کارت / حساب", max_length=100, blank=True)
    to_card = models.CharField("به کارت / حساب", max_length=100, blank=True)
    tracking_number = models.CharField("کد پیگیری", max_length=100, blank=True)
    date = models.DateField("تاریخ", null=True, blank=True)
    time = models.TimeField("ساعت", null=True, blank=True)

    class Meta:
        verbose_name = "تراکنش"
        verbose_name_plural = "تراکنش‌ها"
        ordering = ("-date", "-id")

    def __str__(self):
        return f"{self.amount:,} تومان — {self.contract.number}"


class Setting(models.Model):
    """تنظیمات کسب‌وکار و قالب قرارداد (کلید/مقدار)"""

    key = models.CharField("کلید", max_length=100, primary_key=True)
    value = models.TextField("مقدار", blank=True)

    class Meta:
        verbose_name = "تنظیم"
        verbose_name_plural = "تنظیمات"
        ordering = ("key",)

    def __str__(self):
        return self.key
