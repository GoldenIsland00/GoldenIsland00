from django.contrib import admin
from django.db.models import Count, Sum
from django.utils.html import format_html

from .models import Contract, Customer, Project, Setting, Transaction


def money(value):
    return f"{int(value or 0):,} تومان".replace(",", "،")


class ContractInline(admin.TabularInline):
    model = Contract
    extra = 0
    fields = ("number", "status", "start_date", "end_date", "total_amount")
    show_change_link = True


class TransactionInline(admin.TabularInline):
    model = Transaction
    extra = 0
    fields = ("amount", "date", "time", "from_card", "to_card", "tracking_number")


@admin.register(Customer)
class CustomerAdmin(admin.ModelAdmin):
    list_display = ("name", "phone", "email", "note_code", "contract_count", "total_value")
    list_filter = ("created_at",)
    search_fields = ("name", "phone", "email", "note_code", "national_id", "notes")
    list_per_page = 50
    inlines = [ContractInline]
    readonly_fields = ("created_at", "updated_at")
    fieldsets = (
        ("اطلاعات اصلی", {"fields": ("name", "phone", "email")}),
        ("اطلاعات تکمیلی", {"fields": ("note_code", "national_id", "address", "notes")}),
        ("سیستمی", {"fields": ("created_at", "updated_at"), "classes": ("collapse",)}),
    )

    def get_queryset(self, request):
        return (
            super()
            .get_queryset(request)
            .annotate(_count=Count("contracts"), _sum=Sum("contracts__total_amount"))
        )

    @admin.display(description="تعداد قرارداد", ordering="_count")
    def contract_count(self, obj):
        return obj._count

    @admin.display(description="ارزش کل", ordering="_sum")
    def total_value(self, obj):
        return money(obj._sum)


@admin.register(Contract)
class ContractAdmin(admin.ModelAdmin):
    list_display = (
        "number",
        "customer",
        "status_badge",
        "start_date",
        "end_date",
        "amount_display",
        "paid_display",
        "remaining_display",
    )
    list_filter = ("status", "start_date", "customer")
    search_fields = ("number", "customer__name", "manager_name", "text")
    autocomplete_fields = ("customer",)
    date_hierarchy = "start_date"
    list_per_page = 50
    inlines = [TransactionInline]
    readonly_fields = ("created_at", "updated_at", "paid_display", "remaining_display")
    fieldsets = (
        ("مشخصات قرارداد", {"fields": ("number", "customer", "status")}),
        ("مجری", {"fields": ("manager_name", "manager_info")}),
        ("زمان‌بندی", {"fields": ("start_date", "end_date")}),
        (
            "مالی",
            {"fields": ("total_amount", "prepayment", "paid_display", "remaining_display")},
        ),
        ("ردیف‌های خدمات", {"fields": ("items",), "description": "ساختار: [{\"title\": \"...\", \"qty\": 1, \"price\": 0}]"}),
        ("متن قرارداد", {"fields": ("text",), "classes": ("collapse",)}),
        ("سیستمی", {"fields": ("created_at", "updated_at"), "classes": ("collapse",)}),
    )
    actions = ["mark_completed", "mark_canceled", "mark_active"]

    @admin.display(description="وضعیت", ordering="status")
    def status_badge(self, obj):
        colors = {"active": "#d97706", "completed": "#059669", "canceled": "#dc2626"}
        return format_html(
            '<span style="background:{};color:#fff;padding:2px 9px;border-radius:9px;font-size:11px">{}</span>',
            colors.get(obj.status, "#64748b"),
            obj.get_status_display(),
        )

    @admin.display(description="مبلغ کل", ordering="total_amount")
    def amount_display(self, obj):
        return money(obj.total_amount)

    @admin.display(description="دریافتی")
    def paid_display(self, obj):
        return money(obj.paid)

    @admin.display(description="مانده")
    def remaining_display(self, obj):
        return money(obj.remaining)

    @admin.action(description="تغییر وضعیت به «تکمیل شده»")
    def mark_completed(self, request, queryset):
        self.message_user(request, f"{queryset.update(status='completed')} قرارداد بروزرسانی شد")

    @admin.action(description="تغییر وضعیت به «لغو شده»")
    def mark_canceled(self, request, queryset):
        self.message_user(request, f"{queryset.update(status='canceled')} قرارداد بروزرسانی شد")

    @admin.action(description="تغییر وضعیت به «در حال انجام»")
    def mark_active(self, request, queryset):
        self.message_user(request, f"{queryset.update(status='active')} قرارداد بروزرسانی شد")


@admin.register(Transaction)
class TransactionAdmin(admin.ModelAdmin):
    list_display = ("id", "contract", "amount_display", "date", "time", "tracking_number")
    list_filter = ("date", "contract__customer")
    search_fields = ("tracking_number", "from_card", "to_card", "contract__number", "contract__customer__name")
    autocomplete_fields = ("contract",)
    date_hierarchy = "date"
    list_per_page = 50

    @admin.display(description="مبلغ", ordering="amount")
    def amount_display(self, obj):
        return money(obj.amount)


@admin.register(Project)
class ProjectAdmin(admin.ModelAdmin):
    list_display = ("name", "price_display", "tech_list", "sample_url")
    search_fields = ("name", "description")
    list_per_page = 50
    readonly_fields = ("created_at", "updated_at")

    @admin.display(description="شروع قیمت", ordering="start_price")
    def price_display(self, obj):
        return money(obj.start_price)

    @admin.display(description="تکنولوژی‌ها")
    def tech_list(self, obj):
        return "، ".join(obj.techs or []) or "—"


@admin.register(Setting)
class SettingAdmin(admin.ModelAdmin):
    list_display = ("key", "short_value")
    search_fields = ("key", "value")

    @admin.display(description="مقدار")
    def short_value(self, obj):
        text = (obj.value or "").replace("\n", " ")
        return text[:80] + ("…" if len(text) > 80 else "") or "—"
