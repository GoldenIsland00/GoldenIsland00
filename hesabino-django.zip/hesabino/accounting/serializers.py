"""
تبدیل مدل‌ها به ساختار JSON مورد انتظار رابط کاربری (camelCase)
و برعکس. رابط کاربری دقیقاً همان کلیدهای نسخه IndexedDB را می‌فرستد.
"""
from datetime import datetime

from .models import Contract, Customer, Project, Setting, Transaction


# ---------- ابزارها ----------
def _d(value):
    """DateField → رشته YYYY-MM-DD یا رشته خالی"""
    return value.isoformat() if value else ""


def _t(value):
    """TimeField → رشته HH:MM یا رشته خالی"""
    return value.strftime("%H:%M") if value else ""


def parse_date(value):
    if not value:
        return None
    if isinstance(value, str):
        value = value.strip()[:10]
        try:
            return datetime.strptime(value, "%Y-%m-%d").date()
        except ValueError:
            return None
    return value


def parse_time(value):
    if not value:
        return None
    if isinstance(value, str):
        value = value.strip()
        for fmt in ("%H:%M:%S", "%H:%M"):
            try:
                return datetime.strptime(value, fmt).time()
            except ValueError:
                continue
        return None
    return value


def to_int(value, default=0):
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return default


def to_str(value):
    return "" if value is None else str(value).strip()


# ---------- مشتری ----------
def customer_to_dict(obj):
    return {
        "id": obj.id,
        "name": obj.name,
        "phone": obj.phone,
        "email": obj.email,
        "noteCode": obj.note_code,
        "nationalId": obj.national_id,
        "address": obj.address,
        "notes": obj.notes,
        "createdAt": obj.created_at.isoformat() if obj.created_at else "",
    }


def customer_from_dict(obj, data):
    obj.name = to_str(data.get("name"))[:200]
    obj.phone = to_str(data.get("phone"))[:40]
    obj.email = to_str(data.get("email"))[:254]
    obj.note_code = to_str(data.get("noteCode"))[:60]
    obj.national_id = to_str(data.get("nationalId"))[:40]
    obj.address = to_str(data.get("address"))[:400]
    obj.notes = to_str(data.get("notes"))
    return obj


# ---------- پروژه / خدمت ----------
def project_to_dict(obj):
    return {
        "id": obj.id,
        "name": obj.name,
        "description": obj.description,
        "sampleUrl": obj.sample_url,
        "startPrice": obj.start_price,
        "techs": obj.techs or [],
        "createdAt": obj.created_at.isoformat() if obj.created_at else "",
    }


def project_from_dict(obj, data):
    obj.name = to_str(data.get("name"))[:200]
    obj.description = to_str(data.get("description"))
    obj.sample_url = to_str(data.get("sampleUrl"))[:400]
    obj.start_price = to_int(data.get("startPrice"))
    techs = data.get("techs") or []
    if isinstance(techs, str):
        techs = [t.strip() for t in techs.split(",") if t.strip()]
    obj.techs = [to_str(t) for t in techs if to_str(t)]
    return obj


# ---------- قرارداد ----------
def contract_to_dict(obj):
    return {
        "id": obj.id,
        "number": obj.number,
        "customerId": obj.customer_id,
        "managerName": obj.manager_name,
        "managerInfo": obj.manager_info,
        "startDate": _d(obj.start_date),
        "endDate": _d(obj.end_date),
        "totalAmount": obj.total_amount,
        "prepayment": obj.prepayment,
        "status": obj.status,
        "text": obj.text,
        "items": obj.items or [],
        "createdAt": obj.created_at.isoformat() if obj.created_at else "",
    }


def contract_from_dict(obj, data):
    obj.number = to_str(data.get("number"))[:60]
    customer_id = data.get("customerId")
    if customer_id:
        obj.customer_id = to_int(customer_id, None)
    obj.manager_name = to_str(data.get("managerName"))[:200]
    obj.manager_info = to_str(data.get("managerInfo"))[:400]
    obj.start_date = parse_date(data.get("startDate"))
    obj.end_date = parse_date(data.get("endDate"))
    obj.total_amount = to_int(data.get("totalAmount"))
    obj.prepayment = to_int(data.get("prepayment"))
    status = to_str(data.get("status")) or "active"
    obj.status = status if status in dict(Contract.STATUS_CHOICES) else "active"
    obj.text = to_str(data.get("text"))
    items = data.get("items") or []
    clean = []
    if isinstance(items, list):
        for it in items:
            if not isinstance(it, dict):
                continue
            clean.append(
                {
                    "title": to_str(it.get("title")),
                    "qty": to_int(it.get("qty"), 1),
                    "price": to_int(it.get("price")),
                }
            )
    obj.items = clean
    return obj


# ---------- تراکنش ----------
def transaction_to_dict(obj):
    return {
        "id": obj.id,
        "contractId": obj.contract_id,
        "amount": obj.amount,
        "fromCard": obj.from_card,
        "toCard": obj.to_card,
        "trackingNumber": obj.tracking_number,
        "date": _d(obj.date),
        "time": _t(obj.time),
    }


def transaction_from_dict(obj, data):
    contract_id = data.get("contractId")
    if contract_id:
        obj.contract_id = to_int(contract_id, None)
    obj.amount = to_int(data.get("amount"))
    obj.from_card = to_str(data.get("fromCard"))[:100]
    obj.to_card = to_str(data.get("toCard"))[:100]
    obj.tracking_number = to_str(data.get("trackingNumber"))[:100]
    obj.date = parse_date(data.get("date"))
    obj.time = parse_time(data.get("time"))
    return obj


# ---------- تنظیمات ----------
def setting_to_dict(obj):
    return {"key": obj.key, "value": obj.value}


# نگاشت نام مسیر → (مدل، تابع خروجی، تابع ورودی)
REGISTRY = {
    "customers": (Customer, customer_to_dict, customer_from_dict),
    "projects": (Project, project_to_dict, project_from_dict),
    "contracts": (Contract, contract_to_dict, contract_from_dict),
    "transactions": (Transaction, transaction_to_dict, transaction_from_dict),
}

__all__ = [
    "REGISTRY",
    "Setting",
    "setting_to_dict",
    "customer_to_dict",
    "project_to_dict",
    "contract_to_dict",
    "transaction_to_dict",
]
