"""تست سریع سرتاسری — python3 smoke_test.py"""
import json
import os

import django

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "config.settings")
django.setup()

from django.contrib.auth.models import User  # noqa: E402
from django.test import Client  # noqa: E402

User.objects.filter(username="tester").delete()
User.objects.create_superuser("tester", "t@example.com", "pass12345!")

c = Client()

# 1) بدون ورود → ریدایرکت به صفحه لاگین
r = c.get("/")
assert r.status_code == 302 and "/login/" in r["Location"], r.status_code
r = c.get("/api/customers/")
assert r.status_code == 302, r.status_code
print("✓ حفاظت ورود روی صفحه اصلی و API")

# 2) ورود
assert c.login(username="tester", password="pass12345!")
r = c.get("/")
assert r.status_code == 200
body = r.content.decode()
assert "حسابی‌نو" in body and "{% verbatim %}" not in body
assert "{{contract_number}}" in body, "قالب قرارداد نباید توسط جنگو رندر شود"
assert "HESABINO_USER" in body and "tester" in body
assert "indexedDB" not in body, "لایه IndexedDB باید حذف شده باشد"
print("✓ بارگذاری صفحه برنامه و سالم‌ماندن قالب قرارداد")

# 3) تنظیمات پیش‌فرض
r = c.get("/api/settings/")
s = {x["key"]: x["value"] for x in r.json()}
assert "template" in s and s["companyName"], s
print("✓ تنظیمات پیش‌فرض ساخته شد:", len(s), "کلید")

# 4) مشتری
r = c.post(
    "/api/customers/",
    data=json.dumps({"name": "شرکت آزمون", "phone": "09120000000", "noteCode": "C-1001"}),
    content_type="application/json",
)
assert r.status_code == 201, r.content
cu = r.json()
assert cu["noteCode"] == "C-1001"
print("✓ ایجاد مشتری:", cu["id"])

# 5) قرارداد با ردیف خدمات
r = c.post(
    "/api/contracts/",
    data=json.dumps(
        {
            "number": "0001",
            "customerId": cu["id"],
            "managerName": "مجری تست",
            "startDate": "2026-01-10",
            "endDate": "",
            "totalAmount": 15000000,
            "prepayment": 5000000,
            "status": "active",
            "text": "متن قرارداد",
            "items": [{"title": "طراحی سایت", "qty": 1, "price": 15000000}],
        }
    ),
    content_type="application/json",
)
assert r.status_code == 201, r.content
ct = r.json()
assert ct["startDate"] == "2026-01-10" and ct["endDate"] == ""
assert ct["items"][0]["price"] == 15000000
print("✓ ایجاد قرارداد:", ct["id"])

# 6) تراکنش
r = c.post(
    "/api/transactions/",
    data=json.dumps(
        {
            "contractId": ct["id"],
            "amount": 5000000,
            "fromCard": "6037-...",
            "date": "2026-01-11",
            "time": "14:30",
            "trackingNumber": "TRK-9",
        }
    ),
    content_type="application/json",
)
assert r.status_code == 201, r.content
tx = r.json()
assert tx["time"] == "14:30" and tx["date"] == "2026-01-11"
print("✓ ایجاد تراکنش:", tx["id"])

# 7) ویرایش (PUT)
r = c.put(
    f"/api/contracts/{ct['id']}/",
    data=json.dumps(dict(ct, status="completed", totalAmount=16000000)),
    content_type="application/json",
)
assert r.status_code == 200 and r.json()["status"] == "completed", r.content
print("✓ ویرایش قرارداد")

# 8) حذف مشتریِ دارای قرارداد باید رد شود
r = c.delete(f"/api/customers/{cu['id']}/")
assert r.status_code == 409, r.status_code
print("✓ محافظت از حذف مشتری دارای قرارداد")

# 9) پروژه/خدمت
r = c.post(
    "/api/projects/",
    data=json.dumps({"name": "طراحی سایت", "startPrice": 9000000, "techs": ["Django", "React"]}),
    content_type="application/json",
)
assert r.status_code == 201 and r.json()["techs"] == ["Django", "React"], r.content
print("✓ ایجاد خدمت")

# 10) ذخیره تنظیم
r = c.put(
    "/api/settings/companyName/",
    data=json.dumps({"key": "companyName", "value": "استودیو من"}),
    content_type="application/json",
)
assert r.status_code == 200 and r.json()["value"] == "استودیو من"
print("✓ ذخیره تنظیمات")

# 11) حذف آبشاری تراکنش‌ها همراه قرارداد
c.delete(f"/api/contracts/{ct['id']}/")
assert c.get("/api/transactions/").json() == []
assert c.delete(f"/api/customers/{cu['id']}/").status_code == 200
print("✓ حذف قرارداد و تراکنش‌های وابسته")

# 12) پنل ادمین
for url in ["/admin/", "/admin/accounting/customer/", "/admin/accounting/contract/",
            "/admin/accounting/transaction/", "/admin/accounting/project/",
            "/admin/accounting/setting/", "/admin/accounting/contract/add/"]:
    assert c.get(url).status_code == 200, url
print("✓ همه صفحات پنل ادمین باز می‌شوند")

# 13) صفحه ورود
c.logout()
assert c.get("/login/").status_code == 200
print("✓ صفحه ورود")

User.objects.filter(username="tester").delete()
print("\nهمه تست‌ها با موفقیت انجام شد ✅")
