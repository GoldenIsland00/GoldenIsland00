from django.contrib import admin
from django.urls import include, path

admin.site.site_header = "پنل مدیریت حسابی‌نو"
admin.site.site_title = "حسابی‌نو"
admin.site.index_title = "مدیریت داده‌ها"

urlpatterns = [
    path("admin/", admin.site.urls),
    path("", include("accounting.urls")),
]
